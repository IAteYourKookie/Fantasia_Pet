<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="imagens/paw.png">
    <title>Fantasia Pet</title>

    <!----------------------- Script ----------------------->
        <script>
        // FORM LOGIN
        function openForm() {
            document.getElementById("myForm").style.display = "block";
        }

        function closeForm() {
        document.getElementById("myForm").style.display = "none";
        }

        // REDEFINICAO DE TAMANHO DA NAVBAR
        var mybutton = document.getElementById("topBtn");
        window.onscroll = function() {scrollFunction()};

        function scrollFunction() {
        if (document.body.scrollTop > 80 || document.documentElement.scrollTop > 80) {
            document.getElementById("logo").style.fontSize = "30px";
            document.getElementById("menu").style.visibility = "hidden";
            document.getElementById("menu2").style.visibility = "hidden";
            document.getElementById("menu3").style.visibility = "hidden";
            document.getElementById("img").style.width = "50%";
            document.getElementById("loginbtn").style.width = "100%"
            document.getElementById("fontola").style.fontSize="20px"
            document.getElementById("fontcadastro").style.fontSize="15px"
        } else {
            document.getElementById("logo").style.fontSize = "60px";
            document.getElementById("menu").style.visibility = "visible";
            document.getElementById("menu2").style.visibility = "visible";
            document.getElementById("menu3").style.visibility = "visible";
            document.getElementById("img").style.width = "100%";
            document.getElementById("loginbtn").style.width = "110%"
            document.getElementById("fontola").style.fontSize="22px"
            document.getElementById("fontcadastro").style.fontSize="17px"
        }
        if (document.body.scrollTop > 900 || document.documentElement.scrollTop > 900) {
            document.getElementById("topBtn").style.visibility = "visible";
        }
        else {
            document.getElementById("topBtn").style.visibility = "hidden";
        }
        }
        // VOLTAR AO TOPO
        function topFunction() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
        }
        </script>
      
</head>
<header>
    <!------------------Top Navigation Bar------------------>
        <div id="home"><h1 class="logo" id="logo"><img id="img" src="imagens/header.png" class="imgheader">Fantasia Pet</h1>

        <nav id="nav">
        <ul>
            <li><a id="menu" class="opc" href="index.html">Home</a></li>
            <li><a id="menu2" class="opc" href="sobre.html">Sobre</a></li>
            <li><a id="menu3" class="opc" href="index.html#produtos">Produtos</a></li>
        </ul>
        </nav>
        </div>
        <div class="align-right" style="position: relative; padding-right: 30px; left:50vw;"><button id="loginbtn" style="position:static;" class="buttonlogin" onclick="openForm()"><span style="font-size:20px;" id="fontola">Olá, Entre aqui</span><br><span id="fontcadastro" style="font-size:15px; display: block; margin-top: 0px;"> ou faça seu cadastro</span> </button>
    <!-------------------- Form Login -------------------->
        <div class="form-popup" id="myForm">
        <form action="" class="form-container">
            <p class="logintext">Login</p>
            <p style="float: left;">
            <label for="email" style="float: left;">Email</label>
            <input type="text" placeholder="Insira seu email" name="email" required>
            <label for="psw" style="float: left;">Senha</label>
            <input type="password" placeholder="Insira sua senha" name="psw" required>
            <a href="cadastro.html" style="font-size: small; color: slategrey; float:left; font-family: Arial, Helvetica, sans-serif;">Não é cadastrado ainda? Faça seu registro aqui.</a>  
            </p>
            
            <button type="submit" class="btn">Login</button>
            <button type="button" class="btn cancel" onclick="closeForm()">Fechar</button>
        </form>
        </div></div>
</header>

    <!--------------------- Conteudo ---------------------->
        <!------------------ Form Cadastro ------------------>
            <body><div class="content">
            <center><div>
                <img class="boximgs" src="imagens/dog_PNG50375.png">
                <form action="" class="form-container" style="background-color:#ffffff; float:center; margin-bottom: 30px;">
                <p class="logintext">Cadastro</p>
                <p style="float: left;">
                    <label for="email" style="float: left;">Nome</label>
                <input type="text" placeholder="Insira seu nome" name="name" required>
                <label for="email" style="float: left;">Email</label>
                <input type="text" placeholder="Insira seu email" name="email" required>
                <label for="psw" style="float: left;">Senha</label>
                <input type="password" placeholder="Insira sua senha" name="psw" required>
                <label for="psw" style="float: left;">Confirmação senha</label>
                <input type="password" placeholder="Confime sua senha" name="pswCheck" required>
                </p>
                    
                <button type="submit" class="btn">Cadastrar</button>
                </form>
            </div></div></center>

    <!----------------------- PHP ----------------------->
        <?php
        include "conexao.php";
        if(isset($_REQUEST['psw'])){
            $psw=($_REQUEST['psw']);
            $pswCheck=($_REQUEST['pswCheck']);

            if ($pswCheck==$psw){
                $name=($_REQUEST['name']);
                $email=($_REQUEST['email']);
                mysqli_error();
                mysqli_query($bdOpen,"insert into usuario(name,email,psw,pfp,id) values('$name','$email', '$psw','',NULL)");
                mysqli_close($bdOpen);
            } elseif($pswCheck!=$psw){
                //header("Location: http://localhost/site_lorena/cadastro.php");
                echo "<script>
                location.replace('cadastro.php');
                alert('Senhas não coincidem');</script>";
                //exit();
            }
        }
        
        ?>

  </body>
  <!----------------------- Footer ---------------------->
<footer>© Todos os direitos reservados<br>Lorena Teixeira de Almeida, 2021</footer>
</html>