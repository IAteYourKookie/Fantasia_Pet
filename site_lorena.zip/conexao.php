<?php
    $db_name = 'fantasy';
    $db_host ='localhost';
    $db_user = 'root';
    $db_pass = 'usbw';
    
    $bdOpen = mysqli_connect($db_host,$db_user,$db_pass,$db_name);
    //$pdo = new PDO("mysql:dbname=".$db_name.";host=".$db_host, $db_user, $db_pass);
    ?>