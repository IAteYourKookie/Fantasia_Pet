<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flickity/1.0.0/flickity.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/flickity/1.0.0/flickity.pkgd.js"></script>
    <link rel="icon" href="imagens/paw.png">
    <title>Fantasia Pet</title>

    <!----------------------- Script ----------------------->
      <script>
        // FORM LOGIN
        function openForm() {
          document.getElementById("myForm").style.display = "block";
        }

      function closeForm() {
        document.getElementById("myForm").style.display = "none";
      }

      // REDEFINICAO DE TAMANHO DA NAVBAR
      var mybutton = document.getElementById("topBtn");
      window.onscroll = function() {scrollFunction()};

      function scrollFunction() {
        if (document.body.scrollTop > 80 || document.documentElement.scrollTop > 80) {
          document.getElementById("logo").style.fontSize = "30px";
          document.getElementById("menu").style.visibility = "hidden";
          document.getElementById("menu2").style.visibility = "hidden";
          document.getElementById("menu3").style.visibility = "hidden";
          document.getElementById("img").style.width = "50%";
          document.getElementById("loginbtn").style.width = "100%"
          document.getElementById("fontola").style.fontSize="20px"
          document.getElementById("fontcadastro").style.fontSize="15px"
        } else {
          document.getElementById("logo").style.fontSize = "60px";
          document.getElementById("menu").style.visibility = "visible";
          document.getElementById("menu2").style.visibility = "visible";
          document.getElementById("menu3").style.visibility = "visible";
          document.getElementById("img").style.width = "100%";
          document.getElementById("loginbtn").style.width = "110%"
          document.getElementById("fontola").style.fontSize="22px"
          document.getElementById("fontcadastro").style.fontSize="17px"
        }
        if (document.body.scrollTop > 900 || document.documentElement.scrollTop > 900) {
          document.getElementById("topBtn").style.visibility = "visible";
        }
        else {
          document.getElementById("topBtn").style.visibility = "hidden";
        }
      }
      // VOLTAR AO TOPO
      function topFunction() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
      }
      </script>
      
</head>
<header>
    <!------------------Top Navigation Bar------------------>
      <div id="home"><h1 class="logo" id="logo"><img id="img" src="imagens/header.png" class="imgheader">Fantasia Pet</h1>

      <nav id="nav">
        <ul>
          <li><a id="menu" class="opc" href="index.php">Home</a></li>
          <li><a id="menu2" class="opc" href="sobre.php">Sobre</a></li>
          <li><a id="menu3" class="opc" href="index.php#produtos">Produtos</a></li>
        </ul>
      </nav>
      </div>
      <div class="align-right" style="position: relative; padding-right: 30px; left:50vw;"><button id="loginbtn" style="position:static;" class="buttonlogin" onclick="openForm()"><span style="font-size:20px;" id="fontola">Olá, Entre aqui</span><br><span id="fontcadastro" style="font-size:15px; display: block; margin-top: 0px;"> ou faça seu cadastro</span> </button>
    <!-------------------- Form Login -------------------->
      <div class="form-popup" id="myForm" style="position: fixed;">
        <form action="" class="form-container">
          <p class="logintext">Login</p>
          <p style="float: left;">
          <label for="email" style="float: left;">Email</label>
          <input type="text" placeholder="Insira seu email" name="email" required>
          <label for="psw" style="float: left;">Senha</label>
          <input type="password" placeholder="Insira sua senha" name="psw" required>
          <a href="cadastro.html" style="font-size: small; color: slategrey; float:left; font-family: Arial, Helvetica, sans-serif;">Não é cadastrado ainda? Faça seu registro aqui.</a>  
          </p>
            
          <button type="submit" class="btn">Login</button>
          <button type="button" class="btn cancel" onclick="closeForm()">Fechar</button>
        </form>
      </div></div>
</header>

  <!--------------------- Conteudo ---------------------->
    <!--------------------- Carrossel --------------------->
      <!--<img src="imagens/bg.png" style="float:center; height:60%;object-fit: cover;">-->
      <body><div class="content">
        <div><p style="align-content: center; position: relative;padding-left: 30%;">Notícias</p></div>
        <!-- Flickity HTML init -->
        <div class="gallery js-flickity"
          data-flickity-options='{ "wrapAround": true }'>
          <div class="gallery-cell">
            <div class="grid-container">
              <div class="item1"><div class="imginbox"></div></div>
              <div class="item2" style="text-align:left;"><p><span style="font-size: large; color:#db9d9d;">Parvovirose canina: sintomas,<br>tratamento e prevenção</span><br><span style="font-size: small;">Obrigatória para os cães, a vacina polivalente é muito<br>conhecida pelos tutores. Também chamada pelas<br>nomenclaturas V10 e V8, ela protege o pet contra<br>algumas das principais doenças de origem viral e<br>bacteriana, entre elas a parvovirose canina.</span></p></div>
            </div>
          </div>
          <div class="gallery-cell">
            <div class="grid-container">
              <img style="width: auto;height: 370px;border-radius: 5px;" src="imagens/fundo.jpg">
            </div>
          </div>
          <div class="gallery-cell">
            <div class="grid-container">
              <div class="item1">
              <img style="width: auto;height: 370px;border-radius: 5px;" src="imagens/dog-g4c0a16c89_1920.jpg"></div>
              <div class="item2" style="text-align:left; width: 300px;"><p><span style="font-size: large; color:#db9d9d;">Nomes para cachorro: confira 300 opções criativas</span><br><span style="font-size: small;">Está pensando em adotar um cãozinho, mas ainda não sabe que nome colocar no novo pet? Não se preocupe, pois selecionamos 300 opções criativas de nomes para cachorro. Assim, você escolhe o que tem a ver com os seus gostos e é a cara do amigo peludo.</span></p></div>
            </div>
          </div>
        </div>
        </div><p>
    <!--------------------- Sobre nos --------------------->
      <center><div style="width: 40%;justify-content: left;"><br>
          <p style="text-align: justify;font-family: 'Playfair Display',Arial, Helvetica, sans-serif;color: #E6B1B1;font-size: 25px">
            Quem Somos?<br></p>
            <p style="text-align: justify;;font-family: Arial, Helvetica, sans-serif;color: #413737;font-size: 16px">
            Sabemos que cada laço é único. Fonte de alegria, evolução, bem-estar. Temos experiência e oferecemos espaços, produtos e serviços – e tudo mais que for preciso – para que a relação entre pets e suas famílias seja melhor a cada dia. Essa é nossa razão de ser.
            
            Somos apaixonados por pets! Essa não é apenas uma expressão inserida em nossa missão como empresa, mas uma realidade vivenciada todos os dias em nossas atitudes, nas lojas e em todos os nossos pontos de contato.
            
            Trabalhamos para que você e seus pets tenham a melhor experiência em nossas lojas, seja através dos serviços de estética e veterinária ou pela variedade de produtos espalhados nos mais diversos mundos: cães, gatos, peixes, aves, roedores, répteis. Ah, mantemos nossas orelhas em pé para saber das novidades do mundo pet e levá-las até você.
            
            Conveniência é com a gente! Tudo é preparado e organizado para você encontrar facilmente o que procura, e o melhor: a qualquer hora e no lugar que preferir.
            
            Sabemos que cuidar de nossos bichinhos é um prazer: selecionar a melhor ração, buscar mimos novos, levá-los para um banho. O que importa é ver que eles estão bem.
            
            Muitas vezes, sabemos que seu tempo é curto, mas queremos que você aproveite cada segundo que passar conosco! Para isso, a gente trata todos os pets com muita dedicação e respeito e trabalha a todo instante para que nossas lojas, produtos e serviços estejam à altura de tanto amor e cuidado.
            
            Convidamos você a dar um passeio em nossas lojas, se divertir, trocar ideias, histórias, sentimentos, criar laços, sorrir com a gente. Isso é o que fazemos, e esse é o nosso jeito.
            
            Somos a Petz, seu pet center de estimação!<br><br>
            
            Nossa Missão: Criar valor na interação com os apaixonados por animais de estimação, potencializando o bem da relação entre o pet e sua família.
            <br>
            Nossa Visão: Ser mundialmente reconhecido como melhor ecossistema do segmento pet até 2025.
            <br>
            Nossos Valores:
            <br>
            1. Somos apaixonados por pets;<br>
            2. Respeitamos uns aos outros;<br>
            3. Reconhecemos esforços, premiamos resultados;<br>
            4. Encantamos nossos clientes;<br>
            5. Temos prazer em servir.<br>
            
            *Praticamos os 5 valores todos os dias.</p>
        </div></div></center></p>
</body>
  <!----------------------- Footer ---------------------->
<footer>© Todos os direitos reservados<br>Lorena Teixeira de Almeida, 2021</footer>
</html>