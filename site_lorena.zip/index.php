<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="imagens/paw.png">
    <title>Fantasia Pet</title>

    <!----------------------- Script ----------------------->
    <script>
      // FORM LOGIN
      function openForm() {
        document.getElementById("myForm").style.display = "block";
      }

      function closeForm() {
        document.getElementById("myForm").style.display = "none";
      }

      // REDEFINICAO DE TAMANHO DA NAVBAR
      var mybutton = document.getElementById("topBtn");
      window.onscroll = function() {scrollFunction()};

      function scrollFunction() {
        if (document.body.scrollTop > 80 || document.documentElement.scrollTop > 80) {
          document.getElementById("logo").style.fontSize = "30px";
          document.getElementById("menu").style.visibility = "hidden";
          document.getElementById("menu2").style.visibility = "hidden";
          document.getElementById("menu3").style.visibility = "hidden";
          document.getElementById("img").style.width = "50%";
          document.getElementById("loginbtn").style.width = "100%"
          document.getElementById("fontola").style.fontSize="20px"
          document.getElementById("fontcadastro").style.fontSize="15px"
        } else {
          document.getElementById("logo").style.fontSize = "60px";
          document.getElementById("menu").style.visibility = "visible";
          document.getElementById("menu2").style.visibility = "visible";
          document.getElementById("menu3").style.visibility = "visible";
          document.getElementById("img").style.width = "100%";
          document.getElementById("loginbtn").style.width = "110%"
          document.getElementById("fontola").style.fontSize="22px"
          document.getElementById("fontcadastro").style.fontSize="17px"
        }
        if (document.body.scrollTop > 900 || document.documentElement.scrollTop > 900) {
          document.getElementById("topBtn").style.visibility = "visible";
        }
        else {
          document.getElementById("topBtn").style.visibility = "hidden";
        }
      }
      // VOLTAR AO TOPO
      function topFunction() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
      }
      
  </script>
      
</head>
<header>
    <!------------------Top Navigation Bar------------------>
      <div id="home"><h1 class="logo" id="logo"><img id="img" src="imagens/header.png" class="imgheader">Fantasia Pet</h1>

      <nav id="nav">
        <ul>
          <li><a id="menu" class="opc" href="index.php">Home</a></li>
          <li><a id="menu2" class="opc" href="sobre.php">Sobre</a></li>
          <li><a id="menu3" class="opc" href="#produtos">Produtos</a></li>
        </ul>
      </nav>
      </div>
      <div class="align-right" style="position: relative; padding-right: 30px; left:50vw;"><button id="loginbtn" style="position:static;" class="buttonlogin" onclick="openForm()"><span style="font-size:20px;" id="fontola">Olá, Entre aqui</span><br><span id="fontcadastro" style="font-size:15px; display: block; margin-top: 0px;"> ou faça seu cadastro</span> </button>
    <!-------------------- Form Login -------------------->
      <div class="form-popup" id="myForm">
        <form action="" class="form-container">
          <p class="logintext">Login</p>
          <p style="float: left;">
          <label for="email" style="float: left;">Email</label>
          <input type="text" placeholder="Insira seu email" name="email" required>
          <label for="psw" style="float: left;">Senha</label>
          <input type="password" placeholder="Insira sua senha" name="psw" required>
          <a href="cadastro.html" style="font-size: small; color: slategrey; float:left; font-family: Arial, Helvetica, sans-serif;">Não é cadastrado ainda? Faça seu registro aqui.</a>  
          </p>
            
          <button type="submit" class="btn">Login</button>
          <button type="button" class="btn cancel" onclick="closeForm()">Fechar</button>
        </form>
      </div></div>
</header>

  <!--------------------- Conteudo ---------------------->
    <!--------------------- Banner ---------------------->
      <!--<img src="imagens/bg.png" style="float:center; height:60%;object-fit: cover;">-->
      <body><div class="content">
        <div class="banner">
          <p>
            <span class="titulo">Fantasias estilosas para<br>seus pets<br></span><span class="subtitulo"><br>De acessórios a roupinhas. Vem dar<br> uma olhadinha.<br>
            <button class="button" onclick="window.location.href='sobre.html'" style="float: left;font-size: 40px;font-family: 'Playfair Display',Arial, Helvetica, sans-serif;width: 220px;"><span>Veja mais</span></button></span>
          </p>
        <img class="itemimg" src="imagens/pngegg (11).png" style="width: 50%; float: right; padding-right: 100px; padding-top: 20px;"></div>
    <!--------------------- Fantasias --------------------->
      <div class="contentbody" id="produtos">
        <table><tr>
          <th><p class="box"><img class="boximgs" src="imagens/pngegg(12).png"><br>Fantasia Elfo<br><button class="button" style="vertical-align:middle"><span>Veja mais</span></button></p></th>
          <th><p class="box"><img class="boximgs" src="imagens/pngegg (8).png"><br>Fantasia Bombeiro<br><button class="button" style="vertical-align:middle"><span>Veja mais</span></button></p></th>
          <th><p class="box"><img class="boximgs" src="imagens/pngegg.png"><br>Fantasia Sapo Rei<br><button class="button" style="vertical-align:middle"><span>Veja mais</span></button></p></th>
          <th><p class="box"><img class="boximgs" src="imagens/pngegg (15).png"><br>Fantasia Presidiario<br><button class="button" style="vertical-align:middle"><span>Veja mais</span></button></p></th>
        </tr>
        <tr>
          <th><p class="box"><img class="boximgs" src="imagens/pngegg (10).png"><br>Fantasia Escolar Rebeldes<br><button class="button" style="vertical-align:middle"><span>Veja mais</span></button></p></th>
          <th><p class="box"><img class="boximgs" src="imagens/pngegg (7).png"><br>Fantasia Indiana Jones<br><button class="button" style="vertical-align:middle"><span>Veja mais</span></button></p></th>
          <th><p class="box"><img class="boximgs" src="imagens/pngegg (17).png"><br>Fantasia Capitão America<br><button class="button" style="vertical-align:middle"><span>Veja mais</span></button></p></th>
          <th><p class="box"><img class="boximgs" src="imagens/pngegg (1).png"><br>Fantasia Homem Aranha<br><button class="button" style="vertical-align:middle"><span>Veja mais</span></button></p></th>
          </tr></table>
      </div>
      <button onclick="topFunction()" id="topBtn" >Voltar ao topo</button>
  </body>
  <!----------------------- Footer ---------------------->
<footer>© Todos os direitos reservados<br>Lorena Teixeira de Almeida, 2021</footer>
</html>